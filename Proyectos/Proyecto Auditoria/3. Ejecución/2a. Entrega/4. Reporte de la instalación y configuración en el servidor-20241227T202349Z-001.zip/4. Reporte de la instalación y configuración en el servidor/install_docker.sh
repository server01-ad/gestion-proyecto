#!/bin/bash

# Actualiza los repositorios
echo "Actualizando los repositorios..."
sudo apt-get update -y

# Instala los paquetes necesarios para Docker
echo "Instalando dependencias necesarias..."
sudo apt-get install -y apt-transport-https ca-certificates curl software-properties-common

# Añadir la clave GPG oficial de Docker
echo "Añadiendo la clave GPG oficial de Docker..."
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo apt-key add -

# Añadir el repositorio de Docker
echo "Añadiendo el repositorio de Docker..."
sudo add-apt-repository "deb [arch=amd64] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable"

# Actualiza los repositorios después de añadir Docker
echo "Actualizando los repositorios de nuevo..."
sudo apt-get update -y

# Instalar Docker
echo "Instalando Docker..."
sudo apt-get install -y docker-ce

# Verificar que Docker se instaló correctamente
echo "Verificando la instalación de Docker..."
sudo systemctl enable docker
sudo systemctl start docker
sudo docker --version

# Agregar el usuario actual al grupo Docker para no usar 'sudo' con Docker
echo "Añadiendo el usuario al grupo Docker..."
sudo usermod -aG docker $USER

# Hacer que los cambios de grupo surtan efecto
echo "Haciendo que los cambios de grupo surtan efecto. Cierra sesión y vuelve a ingresar..."
echo "Listo, ya puedes usar Docker sin sudo. Cierra sesión y vuelve a iniciar sesión para aplicar los cambios."

# Instalar Docker Compose
echo "Instalando Docker Compose..."
DOCKER_COMPOSE_VERSION="1.29.2" # Cambia la versión si es necesario
sudo curl -L "https://github.com/docker/compose/releases/download/${DOCKER_COMPOSE_VERSION}/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose

# Asignar permisos de ejecución a Docker Compose
echo "Asignando permisos de ejecución a Docker Compose..."
sudo chmod +x /usr/local/bin/docker-compose

# Verificar que Docker Compose se instaló correctamente
echo "Verificando la instalación de Docker Compose..."
docker-compose --version

# Finalización
echo "Docker y Docker Compose han sido instalados correctamente."
echo "Recuerda cerrar sesión y volver a ingresar para aplicar los cambios al grupo Docker."
