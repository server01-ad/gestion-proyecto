#!/bin/bash

# Detener y eliminar el contenedor existente si está en ejecución
echo "Deteniendo y eliminando el contenedor existente..."
docker stop oax-ms-admin
docker rm oax-ms-admin

# Eliminar la imagen existente
echo "Eliminando la imagen existente..."
docker rmi -f nomokyeame/oax-admin-private:oax-ms-admin-1.0.0


echo "Buscando imágenes relacionadas con 'oax-ms-auditoria'..."
for /f "tokens=1 delims= " %%i in ('docker images -q oax-ms-admin') do (
    echo Eliminando la imagen con ID %%i...
    docker rmi -f %%i || echo No se pudo eliminar la imagen %%i.
)

# Descargar la nueva imagen desde Docker Hub
echo "Descargando la nueva imagen..."
docker pull nomokyeame/oax-admin-private:oax-ms-admin-1.0.0

# Levantar el contenedor con la nueva imagen
echo "Levantando el contenedor..."
docker run -d -p 8081:8081 --name oax-ms-admin nomokyeame/oax-admin-private:oax-ms-admin-1.0.0

echo "Proceso completado exitosamente."
